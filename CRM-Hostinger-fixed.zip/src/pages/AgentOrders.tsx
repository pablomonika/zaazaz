import { useMemo, useState } from "react";
import DualScroll from "../components/DualScroll";
import TotalLivraison from "./TotalLivraison";
import Historique from "./Historique";
import { useStore } from "../store";
import { usePeriod } from "../period";
import type { Order } from "../data/orders";

const statusOptions = ["", "Confirmé", "Annulé", "Rappel", "Suivé", "Appel-1", "Appel-2", "Appel-3", "Appel-4", "Appel-5", "Appel-6", "Whatssap"];
const deliveryOptions = ["", "Livrée", "Retour", "Out Of Stock", "Expédier vers"];

function rowAppearance(order: Order, index: number) {
  const bg =
    order.livraison === "Livrée" ? "#34c759" :
    order.livraison === "Retour" ? "#ff2b2b" :
    order.livraison === "Out Of Stock" ? "#3c78d8" :
    order.livraison === "Expédier vers" ? "#f6b26b" :
    order.statut === "Annulé" ? "#ff2b2b" :
    order.statut === "Rappel" ? "#ffff00" :
    index % 2 ? "#f8f9fa" : "#ffffff";
  return { bg, strike: order.livraison === "Retour" || order.statut === "Annulé" };
}

export default function AgentOrders({ agent }: { agent: string }) {
  const { orders, add, upd, del, saveCheckpoint, savedAt, savedCount } = useStore();
  const { inRange } = usePeriod();

  // Catalogue produits (page PRODUITS) — auto-complétion + prix automatique
  const catalog: { nom: string; link: string; prix: string }[] = useMemo(() => {
    try {
      const s = localStorage.getItem("afrizon_catalog_v1");
      if (s) return JSON.parse(s);
    } catch { /* */ }
    return [];
  }, []);
  const [query, setQuery] = useState("");
  const [view, setView] = useState<"orders" | "total" | "history">("orders");

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return orders.filter((o) => o.agent.toLowerCase() === agent.toLowerCase() && inRange(o.dateCreation))
      .filter((o) => !q || [o.nom, o.telephone, o.ville, o.produit, o.adresse, o.remarques, o.statut, o.livraison].join(" ").toLowerCase().includes(q));
  }, [orders, agent, query, inRange]);

  const stats = useMemo(() => {
    const all = orders.filter((o) => o.agent.toLowerCase() === agent.toLowerCase() && inRange(o.dateCreation));
    const confirme = all.filter((o) => o.statut === "Confirmé").length;
    const livre = all.filter((o) => o.livraison === "Livrée").length;
    const retour = all.filter((o) => o.livraison === "Retour").length;
    const ca = all.filter((o) => o.livraison === "Livrée").reduce((sum, o) => sum + o.prix, 0);
    return { total: all.length, confirme, livre, retour, ca };
  }, [orders, agent, inRange]);

  const addOrder = () => {
    const today = new Date().toISOString().slice(0, 10);
    add({
      dateCreation: today, dateConfirmation: today, statut: "", remarques: "", idCmd: "1",
      nom: "", telephone: "", ville: "", adresse: "", qte: 1, prix: 0, produit: "", livraison: "",
      upsell: 0, carousell: "", agent, link: "", carosellFlag: "", originLead: "", commission: 35, fees: "",
    });
  };

  const set = (id: number, key: keyof Order, value: string) => {
    const numeric = ["qte", "prix", "upsell", "commission"].includes(key);
    upd(id, { [key]: numeric ? Number(value) || 0 : value } as Partial<Order>);
  };

  const headers = ["#", "DATE", "date", "Statut", "Remarques", "Nom & Prénom", "Téléphone", "Ville", "Adresse", "Qte", "Prix", "Produit", "Livraison", "UPSEL", "ORIGIN LEAD", "commision", "🗑️"];
  const widths = [34, 105, 105, 90, 180, 150, 120, 120, 190, 45, 60, 220, 110, 55, 95, 75, 38];

  const Switcher = () => (
    <div className="flex overflow-hidden rounded-lg border border-slate-300">
      {([
        ["orders", "Commandes"],
        ["total", "📊 Total Livraison"],
        ["history", "🕘 Historique"],
      ] as const).map(([key, label]) => (
        <button key={key} onClick={() => setView(key)}
          className={view === key ? "bg-emerald-600 px-3 py-1 font-bold text-white" : "bg-white px-3 py-1 font-medium text-slate-600 hover:bg-slate-50"}>
          {label}
        </button>
      ))}
    </div>
  );

  if (view === "total" || view === "history") {
    return (
      <div dir="ltr" className="flex h-full flex-col bg-white text-xs">
        <div className="flex shrink-0 flex-wrap items-center gap-2 border-b border-slate-300 bg-slate-100 p-2">
          <b className="text-sm">👤 {agent}</b>
          <Switcher />
        </div>
        <div className="flex-1 overflow-hidden">
          {view === "total" ? <TotalLivraison agent={agent} /> : <Historique agent={agent} />}
        </div>
      </div>
    );
  }

  return (
    <div dir="ltr" className="flex h-full flex-col bg-white text-xs">
      <datalist id="catalog-products-agent">
        {catalog.map((p) => <option key={p.nom} value={p.nom} />)}
      </datalist>
      <div className="flex shrink-0 flex-wrap items-center gap-2 border-b border-slate-300 bg-slate-100 p-2">
        <b className="text-sm">👤 {agent}</b>
        <Switcher />
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Rechercher..." className="w-48 rounded border border-slate-300 px-2 py-1" />
        <button onClick={addOrder} className="rounded bg-blue-600 px-3 py-1 font-bold text-white">+ Commande</button>
        <button
          onClick={() => { const n = saveCheckpoint(); alert(`✅ تم الحفظ\n${n} طلبية محفوظة.`); }}
          title="حفظ الوضع الحالي كنقطة استرجاع"
          className="rounded bg-emerald-600 px-3 py-1 font-bold text-white hover:bg-emerald-700"
        >💾 Save CMD</button>
        {savedAt && <span className="rounded bg-emerald-50 px-2 py-1 text-[10px] font-medium text-emerald-700">✓ {savedCount} · {new Date(savedAt).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</span>}
        <span className="ml-auto">CMD: <b>{stats.total}</b> · Confirmé: <b>{stats.confirme}</b> · Livrée: <b>{stats.livre}</b> · Retour: <b>{stats.retour}</b> · CA: <b>{stats.ca.toLocaleString("fr-FR")} DH</b></span>
      </div>

      <div className="flex-1 overflow-hidden">
        <DualScroll>
          <table className="border-collapse">
            <thead>
              <tr>{headers.map((h, i) => <th key={h} className="border border-slate-400 bg-[#4a86c8] px-2 py-1 font-bold text-white whitespace-nowrap" style={{ minWidth: widths[i] }}>{h}</th>)}</tr>
            </thead>
            <tbody>
              {rows.map((o, index) => {
                const { bg, strike } = rowAppearance(o, index);
                const input = "h-full w-full border-0 bg-transparent px-1 py-1 outline-none";
                const style = { background: bg, textDecoration: strike ? "line-through" : "none" };
                return (
                  <tr key={o.id} style={{ background: bg }}>
                    <td className="border border-slate-400 text-center" style={style}>{index + 1}</td>
                    <td className="border border-slate-400 p-0"><input type="date" value={o.dateCreation} onChange={(e) => set(o.id, "dateCreation", e.target.value)} className={input} style={style} /></td>
                    <td className="border border-slate-400 p-0"><input type="date" value={o.dateConfirmation} onChange={(e) => set(o.id, "dateConfirmation", e.target.value)} className={input} style={style} /></td>
                    <td className="border border-slate-400 p-0"><select value={o.statut} onChange={(e) => set(o.id, "statut", e.target.value)} className={input} style={style}>{statusOptions.map((x) => <option key={x} value={x}>{x || "—"}</option>)}</select></td>
                    <td className="border border-slate-400 p-0"><input value={o.remarques} onChange={(e) => set(o.id, "remarques", e.target.value)} className={input} style={style} /></td>
                    <td className="border border-slate-400 p-0"><input value={o.nom} onChange={(e) => set(o.id, "nom", e.target.value)} className={input} style={style} /></td>
                    <td className="border border-slate-400 p-0"><input value={o.telephone} onChange={(e) => set(o.id, "telephone", e.target.value)} className={input} style={style} /></td>
                    <td className="border border-slate-400 p-0"><input value={o.ville} onChange={(e) => set(o.id, "ville", e.target.value)} className={input} style={style} /></td>
                    <td className="border border-slate-400 p-0"><input value={o.adresse} onChange={(e) => set(o.id, "adresse", e.target.value)} className={input} style={style} /></td>
                    <td className="border border-slate-400 p-0"><input type="number" value={o.qte} onChange={(e) => set(o.id, "qte", e.target.value)} className={input} style={style} /></td>
                    <td className="border border-slate-400 p-0"><input type="number" value={o.prix} onChange={(e) => set(o.id, "prix", e.target.value)} className={input} style={style} /></td>
                    <td className="border border-slate-400 p-0">
                      <input list="catalog-products-agent" value={o.produit}
                        onChange={(e) => {
                          const v = e.target.value;
                          const p = catalog.find((x) => x.nom === v);
                          if (p?.prix) upd(o.id, { produit: v, prix: Number(p.prix) || 0, link: p.link || o.link });
                          else set(o.id, "produit", v);
                        }}
                        className={input} style={style} />
                    </td>
                    <td className="border border-slate-400 p-0"><select value={o.livraison} onChange={(e) => set(o.id, "livraison", e.target.value)} className={input} style={style}>{deliveryOptions.map((x) => <option key={x} value={x}>{x || "—"}</option>)}</select></td>
                    <td className="border border-slate-400 p-0"><input type="number" value={o.upsell} onChange={(e) => set(o.id, "upsell", e.target.value)} className={input} style={style} /></td>
                    <td className="border border-slate-400 p-0"><input value={o.originLead} onChange={(e) => set(o.id, "originLead", e.target.value)} className={input} style={style} /></td>
                    <td className="border border-slate-400 p-0"><input type="number" value={o.commission} onChange={(e) => set(o.id, "commission", e.target.value)} className={input} style={style} /></td>
                    <td className="border border-slate-400 text-center" style={{ background: bg }}><button onClick={() => confirm("Supprimer cette commande ?") && del(o.id)} className="text-red-900">✕</button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {!rows.length && <div className="p-8 text-center text-slate-400">Aucune commande pour {agent}</div>}
        </DualScroll>
      </div>
    </div>
  );
}