import { useMemo, useState } from "react";
import { useStore, exportCSV } from "../store";
import { formatDate, type LogEntry } from "../history";

const ACTIONS = {
  add: { label: "Ajout", icon: "＋", cls: "bg-emerald-100 text-emerald-800" },
  edit: { label: "Modification", icon: "✏️", cls: "bg-blue-100 text-blue-800" },
  delete: { label: "Suppression", icon: "🗑️", cls: "bg-red-100 text-red-800" },
} as const;

export default function Historique({ agent }: { agent?: string }) {
  const { logs, agentNames, clearLogs } = useStore();
  const [q, setQ] = useState("");
  const [who, setWho] = useState("all");
  const [act, setAct] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const rows = useMemo(() => {
    const s = q.trim().toLowerCase();
    return logs.filter((l: LogEntry) => {
      if (agent && l.agent.toLowerCase() !== agent.toLowerCase()) return false;
      if (who !== "all" && l.user !== who) return false;
      if (act !== "all" && l.action !== act) return false;
      const day = l.at.slice(0, 10);
      if (from && day < from) return false;
      if (to && day > to) return false;
      if (s && ![l.user, l.agent, l.client, l.field, l.before, l.after, l.snapshot].join(" ").toLowerCase().includes(s)) return false;
      return true;
    });
  }, [logs, agent, who, act, from, to, q]);

  const users = useMemo(() => [...new Set(logs.map((l) => l.user))], [logs]);
  const counts = useMemo(() => ({
    add: rows.filter((l) => l.action === "add").length,
    edit: rows.filter((l) => l.action === "edit").length,
    delete: rows.filter((l) => l.action === "delete").length,
  }), [rows]);

  const th = "border border-slate-300 bg-slate-100 px-3 py-2 text-[11px] font-bold text-slate-700 whitespace-nowrap";
  const td = "border border-slate-200 px-3 py-2 text-xs align-top";
  const sel = "rounded-lg border border-slate-300 px-2 py-1.5 text-sm outline-none focus:border-blue-500";

  return (
    <div dir="ltr" className="flex h-full flex-col bg-slate-50">
      <div className="shrink-0 border-b border-slate-200 bg-white px-4 py-3">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="text-base font-bold text-slate-800">🕘 Historique {agent ? `— ${agent}` : "(toutes les pages)"}</h3>
          <span className="rounded-full bg-slate-800 px-3 py-1 text-xs font-bold text-white">{rows.length} actions</span>
          <span className="rounded-md bg-emerald-100 px-2 py-1 text-[11px] font-bold text-emerald-800">＋ {counts.add}</span>
          <span className="rounded-md bg-blue-100 px-2 py-1 text-[11px] font-bold text-blue-800">✏️ {counts.edit}</span>
          <span className="rounded-md bg-red-100 px-2 py-1 text-[11px] font-bold text-red-800">🗑️ {counts.delete}</span>

          <div className="ml-auto flex gap-2">
            <button
              onClick={() => exportCSV(rows.map((l) => ({
                Date: formatDate(l.at), Utilisateur: l.user, Page: l.agent, Action: ACTIONS[l.action].label,
                Client: l.client, Champ: l.field || "", Avant: l.before || "", Après: l.after || "", Détail: l.snapshot || "",
              })), `historique${agent ? "-" + agent : ""}`)}
              className="rounded-lg bg-teal-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-teal-700">📥 CSV</button>
            {!agent && (
              <button onClick={() => confirm("Effacer tout l'historique ?") && clearLogs()}
                className="rounded-lg bg-red-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-red-700">Effacer</button>
            )}
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔎 Rechercher (client, champ, valeur…)" className={sel + " w-64"} />
          <select value={who} onChange={(e) => setWho(e.target.value)} className={sel}>
            <option value="all">Tous les utilisateurs</option>
            {users.map((u) => <option key={u} value={u}>{u}</option>)}
          </select>
          <select value={act} onChange={(e) => setAct(e.target.value)} className={sel}>
            <option value="all">Toutes les actions</option>
            <option value="add">Ajout</option>
            <option value="edit">Modification</option>
            <option value="delete">Suppression</option>
          </select>
          {!agent && agentNames.length > 0 && <span className="text-xs text-slate-400">|</span>}
          <label className="text-xs text-slate-500">Du</label>
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className={sel} />
          <label className="text-xs text-slate-500">Au</label>
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className={sel} />
          <button onClick={() => { setQ(""); setWho("all"); setAct("all"); setFrom(""); setTo(""); }}
            className="rounded-lg bg-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-300">Réinitialiser</button>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4">
        <table className="w-full border-collapse bg-white">
          <thead className="sticky top-0 z-10">
            <tr>
              {["Date & heure", "Utilisateur", "Page", "Action", "Client", "Champ", "Avant", "Après / Détail"].map((h) => <th key={h} className={th}>{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {rows.map((l) => {
              const a = ACTIONS[l.action];
              return (
                <tr key={l.id} className="even:bg-slate-50">
                  <td className={td + " whitespace-nowrap text-slate-500"}>{formatDate(l.at)}</td>
                  <td className={td + " font-bold text-slate-800"}>{l.user}</td>
                  <td className={td + " whitespace-nowrap"}>{l.agent || "—"}</td>
                  <td className={td}>
                    <span className={`inline-block whitespace-nowrap rounded-md px-2 py-1 text-[11px] font-bold ${a.cls}`}>{a.icon} {a.label}</span>
                  </td>
                  <td className={td + " font-medium"}>{l.client || "—"}</td>
                  <td className={td + " whitespace-nowrap font-medium text-slate-700"}>{l.field || "—"}</td>
                  <td className={td}>
                    {l.before ? <span className="rounded bg-red-50 px-2 py-0.5 text-red-700 line-through">{l.before}</span> : "—"}
                  </td>
                  <td className={td}>
                    {l.after
                      ? <span className="rounded bg-emerald-50 px-2 py-0.5 font-medium text-emerald-700">{l.after}</span>
                      : <span className="text-slate-600">{l.snapshot || "—"}</span>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {!rows.length && <p className="py-16 text-center text-slate-400">Aucune action enregistrée</p>}
      </div>
    </div>
  );
}
