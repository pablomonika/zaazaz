import { useState } from "react";
import { useAuth } from "../auth";
import { useStore } from "../store";

export default function UsersAdmin() {
  const { users, addUser, updateUser, removeUser, changeAdminPassword } = useAuth();
  const { agentNames } = useStore();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [agent, setAgent] = useState(agentNames[0] || "");

  const add = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addUser(username, password, agent)) return alert("تأكد من المعلومات أو اسم المستخدم موجود");
    setUsername(""); setPassword("");
  };

  return (
    <div dir="rtl" className="h-full overflow-auto p-5">
      <h2 className="text-xl font-bold">إدارة المستخدمين</h2>
      <form onSubmit={add} className="mt-4 flex flex-wrap gap-2 rounded-xl border border-slate-200 bg-slate-50 p-4">
        <input required value={username} onChange={(e) => setUsername(e.target.value)} placeholder="اسم المستخدم" className="rounded border border-slate-300 px-3 py-2" />
        <input required type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="كلمة المرور" className="rounded border border-slate-300 px-3 py-2" />
        <select value={agent} onChange={(e) => setAgent(e.target.value)} className="rounded border border-slate-300 px-3 py-2">{agentNames.map((a) => <option key={a}>{a}</option>)}</select>
        <button className="rounded bg-blue-600 px-4 py-2 font-bold text-white">إضافة User</button>
      </form>

      <div className="mt-4 overflow-x-auto">
        <table className="w-full border-collapse text-sm">
          <thead><tr className="bg-slate-800 text-white"><th className="border p-2">Username</th><th className="border p-2">Role</th><th className="border p-2">صفحة البنت</th><th className="border p-2">Password</th><th className="border p-2">مسح</th></tr></thead>
          <tbody>{users.map((u) => (
            <tr key={u.id} className="even:bg-slate-50">
              <td className="border p-1"><input value={u.username} disabled={u.role === "admin"} onChange={(e) => updateUser(u.id, { username: e.target.value })} className="w-full bg-transparent p-1" /></td>
              <td className="border p-2 text-center">{u.role}</td>
              <td className="border p-1">{u.role === "admin" ? "كل الصفحات" : <select value={u.agent} onChange={(e) => updateUser(u.id, { agent: e.target.value })} className="w-full bg-transparent p-1">{agentNames.map((a) => <option key={a}>{a}</option>)}</select>}</td>
              <td className="border p-1"><input type="text" value={u.password} onChange={(e) => updateUser(u.id, { password: e.target.value })} className="w-full bg-transparent p-1" /></td>
              <td className="border p-2 text-center">{u.role === "user" && <button onClick={() => confirm("مسح المستخدم؟") && removeUser(u.id)} className="text-red-600">✕</button>}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>

      <button onClick={() => { const p = prompt("كلمة مرور Admin الجديدة (6 أحرف على الأقل):"); if (p && !changeAdminPassword(p)) alert("كلمة المرور قصيرة"); }} className="mt-5 rounded bg-amber-500 px-4 py-2 font-bold">تغيير Password ديال Admin</button>
    </div>
  );
}