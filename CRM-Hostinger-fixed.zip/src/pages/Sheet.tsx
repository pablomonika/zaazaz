import { useCallback, useMemo, useState } from "react";
import { useStore, exportCSV } from "../store";
import type { Order } from "../data/orders";
import DualScroll from "../components/DualScroll";
import { usePeriod } from "../period";

const fmt = (n: number) => n.toLocaleString("fr-FR");


function Cell({ val, onChange, w, bg, type = "text", opts, strike = "none" }: { val: string | number; onChange: (v: string) => void; w: number; bg?: string; type?: string; opts?: string[]; strike?: string }) {
  const style = { minWidth: w, background: bg || "" };
  if (opts) return (
    <td style={style} className="border border-slate-300 p-0">
      <select value={String(val)} onChange={(e) => onChange(e.target.value)} className="h-full w-full border-0 bg-transparent px-1 py-[3px] text-xs font-semibold outline-none" style={{ background: bg || "", textDecoration: strike }}>
        {opts.map((o) => <option key={o} value={o}>{o || "—"}</option>)}
      </select>
    </td>
  );
  return (
    <td style={style} className="border border-slate-300 p-0">
      <input type={type} value={val} onChange={(e) => onChange(e.target.value)} className="h-full w-full border-0 bg-transparent px-1 py-[3px] text-xs outline-none" style={{ background: bg || "", textDecoration: strike }} />
    </td>
  );
}

export default function Sheet() {
  const { orders: allOrders, agentNames, gs, upd, add, del, reset, saveCheckpoint, savedAt, savedCount } = useStore();
  const { inRange, label } = usePeriod();
  const [q, setQ] = useState("");

  // Catalogue produits (géré depuis la page PRODUITS)
  const catalog: { nom: string; link: string; prix: string }[] = useMemo(() => {
    try {
      const s = localStorage.getItem("afrizon_catalog_v1");
      if (s) return JSON.parse(s);
    } catch { /* */ }
    return [];
  }, []);

  const orders = useMemo(() => allOrders.filter((o: Order) => inRange(o.dateCreation)), [allOrders, inRange]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return orders;
    return orders.filter((o: Order) => [o.nom, o.telephone, o.ville, o.produit, o.adresse, o.remarques, o.agent, o.statut, o.livraison, o.originLead].join(" ").toLowerCase().includes(s));
  }, [orders, q]);

  const kpi = useMemo(() => {
    const conf = orders.filter((o: Order) => o.statut === "Confirmé");
    const liv = orders.filter((o: Order) => o.livraison === "Livrée");
    const ret = orders.filter((o: Order) => o.livraison === "Retour");
    const ann = orders.filter((o: Order) => o.statut === "Annulé");
    const ca = liv.reduce((s: number, o: Order) => s + o.prix, 0);
    const pcs = liv.reduce((s: number, o: Order) => s + o.qte, 0);
    return {
      cmd: orders.length, conf: conf.length, liv: liv.length, ret: ret.length, ann: ann.length, ca, pcs,
      confRate: orders.length ? ((conf.length / orders.length) * 100).toFixed(2) + "%" : "0%",
      livRate: liv.length + ret.length ? ((liv.length / (liv.length + ret.length)) * 100).toFixed(2) + "%" : "0%",
    };
  }, [orders]);

  const agentRows = useMemo(() => agentNames.map((name) => {
    const list = orders.filter((o) => o.agent.toLowerCase() === name.toLowerCase());
    const confirme = list.filter((o) => o.statut === "Confirmé").length;
    const rappel = list.filter((o) => o.statut === "Rappel").length;
    const annule = list.filter((o) => o.statut === "Annulé").length;
    const livre = list.filter((o) => o.livraison === "Livrée").length;
    const retour = list.filter((o) => o.livraison === "Retour").length;
    const expedierVers = list.filter((o) => o.livraison === "Expédier vers").length;
    const whatssap = list.filter((o) => o.statut === "Whatssap" || o.originLead.toLowerCase() === "whatssap").length;
    const upsell = list.reduce((sum, o) => sum + o.upsell, 0);
    return {
      name, confirme, rappel, annule, livre, retour, expedierVers, whatssap, upsell, carousell: 0,
      confRate: list.length ? ((confirme / list.length) * 100).toFixed(2) + "%" : "0%",
      livrRate: livre + retour ? ((livre / (livre + retour)) * 100).toFixed(2) + "%" : "0%",
      rateTotale: list.length ? ((livre / list.length) * 100).toFixed(2) + "%" : "0%",
    };
  }), [orders, agentNames]);

  const ch = useCallback((id: number, key: keyof Order, val: string) => {
    const nums: (keyof Order)[] = ["qte", "prix", "commission", "upsell"];
    upd(id, { [key]: nums.includes(key) ? Number(val) || 0 : val } as Partial<Order>);
  }, [upd]);

  const addRow = () => add({
    dateCreation: new Date().toISOString().slice(0, 10), dateConfirmation: new Date().toISOString().slice(0, 10),
    statut: "", remarques: "", idCmd: "1", nom: "", telephone: "", ville: "", adresse: "",
    qte: 1, prix: 0, produit: "", livraison: "", upsell: 0, carousell: "",
    agent: "", link: "", carosellFlag: "", originLead: "", commission: 35, fees: "",
  });

  const th = (bg: string) => `border border-slate-400 ${bg} text-white px-1 py-1 text-[11px] font-bold text-center whitespace-nowrap`;
  const B = th("bg-[#4a86c8]"), G = th("bg-[#6aa84f]"), Y = `border border-slate-400 bg-[#f1c232] text-slate-800 px-1 py-1 text-[11px] font-bold text-center whitespace-nowrap`, R = th("bg-[#cc0000]"), D = th("bg-[#999]");
  const c = "border border-slate-300 px-1 py-[2px] text-center";

  return (
    <div dir="ltr" className="flex h-full flex-col bg-white text-xs text-slate-800">
      {/* Liste des produits du catalogue (auto-complétion + prix auto) */}
      <datalist id="catalog-products">
        {catalog.map((p) => <option key={p.nom} value={p.nom} />)}
      </datalist>
      {/* Toolbar */}
      <div className="flex shrink-0 flex-wrap items-center gap-2 border-b border-slate-300 bg-[#f0f0f0] px-3 py-2 shadow-sm">
        <b className="text-sm">📋 RodaMar</b>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔎 بحث..." className="rounded border border-slate-300 px-2 py-1 text-xs w-48" />
        <button onClick={addRow} className="rounded bg-[#4a86c8] px-3 py-1 text-white font-bold">+ Ligne</button>
        <button onClick={() => exportCSV(orders as unknown as Record<string, unknown>[], "afrizon")} className="rounded bg-[#45818e] px-3 py-1 text-white font-bold">📥 CSV</button>
        <button onClick={() => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify(orders, null, 2)])); a.download = "backup.json"; a.click(); }} className="rounded bg-slate-700 px-3 py-1 text-white font-bold">💾 JSON</button>
        <button
          onClick={() => { const n = saveCheckpoint(); alert(`✅ تم الحفظ\n${n} طلبية محفوظة.\nزر Reset غادي يرجع لهاد النقطة.`); }}
          title="حفظ الوضع الحالي كنقطة استرجاع"
          className="rounded bg-emerald-600 px-3 py-1 text-white font-bold hover:bg-emerald-700"
        >💾 Save CMD</button>
        <button
          onClick={() => confirm(savedAt ? `الرجوع لآخر حفظ (${savedCount} طلبية)؟` : "ما كاين حتى حفظ — الرجوع للبيانات الأصلية؟") && reset()}
          title={savedAt ? `آخر حفظ: ${new Date(savedAt).toLocaleString("fr-FR")}` : "ما كاين حتى حفظ"}
          className="rounded bg-red-600 px-3 py-1 text-white font-bold"
        >↺ Reset</button>
        {savedAt && <span className="rounded bg-emerald-50 px-2 py-1 text-[10px] font-medium text-emerald-700">✓ {savedCount} · {new Date(savedAt).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</span>}
        <span className="rounded bg-orange-50 px-2 py-1 text-[10px] font-bold text-orange-700">⏱ {label}</span>
        <span className="ml-auto text-slate-500 text-[10px]">{orders.length} lignes · CA {fmt(kpi.ca)} DH</span>
      </div>

      <div className="flex-1 overflow-hidden">
       <DualScroll>
        {/* ══ Agent Summary ══ */}
        <table className="border-collapse text-xs">
          <thead>
            <tr>
              <th className={D} style={{ width: 85 }}></th>
              <th className={G}>Confirmé</th><th className={Y}>Rappel</th><th className={R}>Annulé</th>
              <th className={B}>CONF RATE</th><th className={G}>livré</th><th className={R}>retour</th>
              <th className={B}>Expédier vers</th><th className={G}>whatssap</th>
              <th className={B}>LIVR RATE</th><th className={B}>Rate totale</th><th className={Y}>UPSELL</th><th className={D}>CAROUSELL</th>
              <th className="w-2 border border-slate-200"></th>
              <th className={B}>DATE TODAY</th><th className={D}></th>
              <th className={G}>CMD livrée</th><th className={G}>CMD confirmé</th><th className={Y}>CMD rechengé</th>
              <th className={R}>CMD Annulé</th><th className={R}>CMD retourner</th>
              <th className={B}>chaifre d&apos;affaire</th><th className={B}>totale pieces sortie</th>
            </tr>
          </thead>
          <tbody>
            {agentRows.map((a, i) => (
              <tr key={a.name} className={i % 2 ? "bg-[#f8f9fa]" : ""}>
                <td className={`${c} font-bold text-left px-2`}>{a.name}</td>
                <td className={`${c} bg-emerald-50`}>{a.confirme}</td>
                <td className={`${c} bg-yellow-50`}>{a.rappel}</td>
                <td className={`${c} bg-rose-50`}>{a.annule}</td>
                <td className={`${c} font-bold text-emerald-700`}>{a.confRate}</td>
                <td className={c}>{a.livre}</td><td className={c}>{a.retour}</td>
                <td className={c}>{a.expedierVers}</td><td className={c}>{a.whatssap}</td>
                <td className={`${c} font-bold text-sky-700`}>{a.livrRate}</td>
                <td className={c}>{a.rateTotale}</td><td className={c}>{a.upsell}</td><td className={c}>{a.carousell}</td>
                <td className="border border-slate-200"></td>
                {i === 0 && <><td className={`${c} font-bold`}>{gs.dateToday}</td><td className={`${c} text-[10px]`}>FROM</td><td className={c}></td><td className={c}></td><td className={c}></td><td className={c}></td><td className={c}></td><td className={c}></td><td className={c}></td></>}
                {i === 1 && <><td className={c}></td><td className={`${c} font-bold`}>{gs.from}</td><td className={`${c} font-bold text-emerald-700`}>{kpi.liv}</td><td className={`${c} font-bold`}>{kpi.conf}</td><td className={c}>{orders.filter((o) => o.livraison === "Expédier vers").length}</td><td className={`${c} text-rose-600 font-bold`}>{kpi.ann}</td><td className={c}>{kpi.ret}</td><td className={`${c} font-bold`}>{kpi.ca}</td><td className={c}>{kpi.pcs}</td></>}
                {i === 2 && <><td className={c}></td><td className={`${c} text-[10px]`}>TO</td><td className={`${c} text-[10px]`}>Tx livraison</td><td className={`${c} text-[10px]`}>Tx confirmation</td><td className={`${c} text-[10px]`}>charge livraison</td><td className={`${c} text-[10px]`}>Tx annulation</td><td className={`${c} text-[10px]`}>CMD</td><td className={c}></td><td className={c}></td></>}
                {i === 3 && <><td className={c}></td><td className={`${c} font-bold`}>{gs.to}</td><td className={`${c} font-bold`}>{kpi.livRate}</td><td className={`${c} font-bold`}>{kpi.confRate}</td><td className={`${c} font-bold`}>{gs.chargeLivraison}</td><td className={c}>{kpi.cmd ? ((kpi.ann / kpi.cmd) * 100).toFixed(2) + "%" : "0%"}</td><td className={`${c} font-bold`}>{kpi.cmd}</td><td className={c}></td><td className={c}></td></>}
                {i >= 4 && Array.from({ length: 9 }).map((_, j) => <td key={j} className="border border-slate-200"></td>)}
              </tr>
            ))}
          </tbody>
        </table>

        <div className="h-2"></div>

        {/* ══ Orders ══ */}
        <table className="w-full border-collapse text-xs">
          <thead className="sticky top-[41px] z-20">
            <tr>
              <th className={D} style={{ width: 28 }}>#</th>
              <th className={B} style={{ width: 88 }}>DATE</th><th className={B} style={{ width: 88 }}>date</th>
              <th className={B} style={{ width: 72 }}>Statut</th><th className={Y} style={{ width: 180 }}>Remarques</th>
              <th className={B} style={{ width: 28 }}>ID</th><th className={G} style={{ width: 145 }}>Nom&amp; Prénom</th>
              <th className={G} style={{ width: 105 }}>Télephone</th><th className={B} style={{ width: 115 }}>Ville</th>
              <th className={B} style={{ width: 190 }}>Adress</th><th className={B} style={{ width: 33 }}>Qte</th>
              <th className={G} style={{ width: 48 }}>Prix</th><th className={G} style={{ width: 200 }}>Produit</th>
              <th className={B} style={{ width: 72 }}>GHYUJH</th><th className={Y} style={{ width: 40 }}>UPSEL</th>
              <th className={D} style={{ width: 120 }}>CAROUSELL</th><th className={B} style={{ width: 72 }}>Agent</th>
              <th className={B} style={{ width: 210 }}>LINK</th><th className={B} style={{ width: 60 }}>CAROSELL</th>
              <th className={B} style={{ width: 85 }}>ORIGIN LEAD</th><th className={G} style={{ width: 68 }}>commision</th>
              <th className={D} style={{ width: 48 }}>FEES</th><th className={R} style={{ width: 35 }}>🗑️</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((o: Order, idx: number) => {
              // Row coloring like Google Sheets — Livraison prioritaire, puis Statut
              const liv = o.livraison;
              const st = o.statut;
              const isRetour = liv === "Retour";
              const isAnnule = st === "Annulé";
              const rowBg =
                liv === "Livrée" ? "#34c759" :              // vert
                liv === "Retour" ? "#ff2b2b" :              // rouge
                liv === "Out Of Stock" ? "#3c78d8" :        // bleu
                (liv === "Expédier vers" || liv === "Expédié") ? "#f6b26b" : // orange
                st === "Annulé" ? "#ff2b2b" :               // rouge
                st === "Rappel" ? "#ffff00" :               // jaune
                (idx % 2 ? "#f8f9fa" : "#ffffff");          // blanc (Confirmé/Appel/Whatssap)
              const strike = (isRetour || isAnnule) ? "line-through" : "none";
              const rowStyle = { background: rowBg, textDecoration: strike };
              return (
              <tr key={o.id} style={{ background: rowBg }} className="hover:brightness-95">
                <td className="border border-slate-300 px-1 text-center text-slate-500" style={rowStyle}>{idx + 1}</td>
                <Cell val={o.dateCreation} onChange={(v) => ch(o.id, "dateCreation", v)} w={88} type="date" bg={rowBg} strike={strike} />
                <Cell val={o.dateConfirmation} onChange={(v) => ch(o.id, "dateConfirmation", v)} w={88} type="date" bg={rowBg} strike={strike} />
                <Cell val={o.statut} onChange={(v) => ch(o.id, "statut", v)} w={90} bg={rowBg} strike={strike} opts={["", "Confirmé", "Annulé", "Rappel", "Suivé", "Appel-1", "Appel-2", "Appel-3", "Appel-4", "Appel-5", "Appel-6", "Whatssap"]} />
                <Cell val={o.remarques} onChange={(v) => ch(o.id, "remarques", v)} w={180} bg={rowBg} strike={strike} />
                <Cell val={o.idCmd} onChange={(v) => ch(o.id, "idCmd", v)} w={28} bg={rowBg} strike={strike} />
                <Cell val={o.nom} onChange={(v) => ch(o.id, "nom", v)} w={145} bg={rowBg} strike={strike} />
                <td className="border border-slate-300 p-0" style={{ minWidth: 105, background: rowBg }}>
                  <div className="flex items-center">
                    <input value={o.telephone} onChange={(e) => ch(o.id, "telephone", e.target.value)} style={{ textDecoration: strike }} className="flex-1 border-0 bg-transparent px-1 py-[3px] text-xs outline-none min-w-0" />
                    {o.telephone && <a href={`https://wa.me/${o.telephone.replace(/[^0-9]/g, "")}`} target="_blank" rel="noreferrer" className="shrink-0 px-0.5 text-emerald-600">💬</a>}
                  </div>
                </td>
                <Cell val={o.ville} onChange={(v) => ch(o.id, "ville", v)} w={115} bg={rowBg} strike={strike} />
                <Cell val={o.adresse} onChange={(v) => ch(o.id, "adresse", v)} w={190} bg={rowBg} strike={strike} />
                <Cell val={o.qte} onChange={(v) => ch(o.id, "qte", v)} w={33} type="number" bg={rowBg} strike={strike} />
                <Cell val={o.prix} onChange={(v) => ch(o.id, "prix", v)} w={48} type="number" bg={rowBg} strike={strike} />
                <td style={{ minWidth: 200, background: rowBg }} className="border border-slate-300 p-0">
                  <input list="catalog-products" value={o.produit}
                    onChange={(e) => {
                      const v = e.target.value;
                      ch(o.id, "produit", v);
                      const p = catalog.find((x) => x.nom === v);
                      if (p?.prix) upd(o.id, { produit: v, prix: Number(p.prix) || 0, link: p.link || o.link });
                    }}
                    className="h-full w-full border-0 bg-transparent px-1 py-[3px] text-xs outline-none"
                    style={{ background: rowBg, textDecoration: strike }} />
                </td>
                <Cell val={o.livraison} onChange={(v) => ch(o.id, "livraison", v)} w={110} bg={rowBg} strike={strike} opts={["", "Livrée", "Retour", "Out Of Stock", "Expédier vers"]} />
                <Cell val={o.upsell} onChange={(v) => ch(o.id, "upsell", v)} w={40} type="number" bg={rowBg} strike={strike} />
                <Cell val={o.carousell} onChange={(v) => ch(o.id, "carousell", v)} w={120} bg={rowBg} strike={strike} />
                <Cell val={o.agent} onChange={(v) => ch(o.id, "agent", v)} w={90} bg={rowBg} strike={strike} opts={["", ...agentNames]} />
                <td className="border border-slate-300 p-0" style={{ minWidth: 210, background: rowBg }}>
                  <div className="flex items-center">
                    <input value={o.link} onChange={(e) => ch(o.id, "link", e.target.value)} className="flex-1 border-0 bg-transparent px-1 py-[3px] text-xs outline-none text-blue-600 underline min-w-0" />
                    {o.link && <a href={o.link} target="_blank" rel="noreferrer" className="shrink-0 px-0.5">🔗</a>}
                  </div>
                </td>
                <Cell val={o.carosellFlag} onChange={(v) => ch(o.id, "carosellFlag", v)} w={60} bg={rowBg} strike={strike} />
                <Cell val={o.originLead} onChange={(v) => ch(o.id, "originLead", v)} w={85} bg={rowBg} strike={strike} opts={["", "Facebook", "whatssap", "Appel", "TikTok"]} />
                <Cell val={o.commission} onChange={(v) => ch(o.id, "commission", v)} w={68} type="number" bg={rowBg} strike={strike} />
                <Cell val={o.fees} onChange={(v) => ch(o.id, "fees", v)} w={48} bg={rowBg} strike={strike} />
                <td className="border border-slate-300 text-center" style={{ background: rowBg }}>
                  <button onClick={() => del(o.id)} className="text-red-500 hover:text-red-700 text-sm">✕</button>
                </td>
              </tr>
            );
            })}
          </tbody>
        </table>
        {!filtered.length && <div className="p-8 text-center text-slate-400">لا توجد نتائج للبحث</div>}
       </DualScroll>
      </div>

      {/* Footer */}
      <div className="shrink-0 flex flex-wrap items-center justify-between gap-2 border-t border-slate-300 bg-[#e8e8e8] px-3 py-1 text-[11px] text-slate-600">
        <span>{filtered.length}/{orders.length} lignes</span>
        <span>CMD:{kpi.cmd} · Confirmé:{kpi.conf} · Livrée:{kpi.liv} · Retour:{kpi.ret} · Annulé:{kpi.ann} · CA:{fmt(kpi.ca)} DH · Pièces:{kpi.pcs}</span>
      </div>
    </div>
  );
}
