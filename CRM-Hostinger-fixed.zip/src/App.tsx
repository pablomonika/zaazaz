import { useState, useEffect } from "react";
import { StoreProvider, useStore } from "./store";
import { AuthProvider, useAuth } from "./auth";
import Sheet from "./pages/Sheet";
import Grid from "./pages/Grid";
import { Produits, BlankSheet } from "./pages/Tabs";
import { SuiviConfirmationView } from "./pages/Dashboards";
import AgentOrders from "./pages/AgentOrders";
import Login from "./pages/Login";
import UsersAdmin from "./pages/UsersAdmin";
import Historique from "./pages/Historique";
import WorkTeam from "./pages/WorkTeam";
import Ranking from "./pages/Ranking";
import LiveActivity from "./pages/LiveActivity";
import Heatmap from "./pages/Heatmap";
import { PeriodProvider, PeriodBar } from "./period";
import { SHEETS, type SheetData } from "./data/sheets";

const CUSTOM_VIEWS = ["suivi confirmation"];

const DEFAULT_TABS = [
  "COMONDES", "Dashboard performance", "LES RENV", "PRODUITS", "LES OBJECTIFS",
  "suivi confirmation", "pièce", "RECLAMATION",
  "statistique", "suivi rentabilité", "Sheet129",
];
const LOCKED = ["Dashboard performance", "LES RENV", "LES OBJECTIFS", "suivi confirmation", "RECLAMATION", "suivi rentabilité"];
const FIXED = ["COMONDES", "PRODUITS", "Work Team"]; // pages avec composant spécial (non supprimables)

const TABS_KEY = "tabs_list_v1";
const CUSTOM_KEY = "custom_sheets_v1";

function Workspace() {
  const { agentNames, addAgent, renameAgent, removeAgent } = useStore();
  const { currentUser, logout, users, updateUser } = useAuth();
  const isAdmin = currentUser?.role === "admin";
  const [tabs, setTabs] = useState<string[]>(() => {
    try { const s = localStorage.getItem(TABS_KEY); if (s) return JSON.parse(s); } catch { /* */ }
    return DEFAULT_TABS;
  });
  // custom (added) sheets data
  const [custom, setCustom] = useState<Record<string, SheetData>>(() => {
    try { const s = localStorage.getItem(CUSTOM_KEY); if (s) return JSON.parse(s); } catch { /* */ }
    return {};
  });
  const [tab, setTab] = useState("COMONDES");

  useEffect(() => {
    if (!isAdmin && currentUser?.agent) setTab(currentUser.agent);
  }, [isAdmin, currentUser]);

  useEffect(() => { localStorage.setItem(TABS_KEY, JSON.stringify(tabs)); }, [tabs]);
  useEffect(() => { localStorage.setItem(CUSTOM_KEY, JSON.stringify(custom)); }, [custom]);

  // Les pages des filles et "Work Team" ne s'affichent plus dans la barre du bas
  // (elles restent accessibles via le bouton 👥 Work Team).
  useEffect(() => {
    setTabs((current) => {
      const hidden = new Set(["Imane", "SANAE", "Work Team", ...agentNames]);
      const cleaned = current.filter((t) => !hidden.has(t));
      return cleaned.length === current.length ? current : cleaned;
    });
  }, [agentNames]);

  const addAgentPage = () => {
    const name = prompt("اسم البنت الجديدة:");
    if (!name) return;
    if (!addAgent(name)) { alert("الاسم موجود أو غير صالح"); return; }
    setTab("Work Team");
  };

  const addTab = () => {
    const name = prompt("اسم الصفحة الجديدة:");
    if (!name || tabs.includes(name)) { if (name) alert("الاسم موجود بالفعل"); return; }
    setTabs((p) => [...p, name]);
    setCustom((p) => ({ ...p, [name]: { headers: ["A", "B", "C", "D", "E", "F"], rows: [Array(6).fill("")] } }));
    setTab(name);
  };

  const delTab = (name: string) => {
    if (FIXED.includes(name)) { alert("هاد الصفحة ما يمكنش تمسح"); return; }
    if (agentNames.includes(name)) {
      if (!confirm(`مسح البنت "${name}" والصفحة ديالها؟ الطلبيات ديالها غاتبقى محفوظة ولكن بلا وكيلة.`)) return;
      users.filter((u) => u.role === "user" && u.agent === name).forEach((u) => updateUser(u.id, { agent: "" }));
      removeAgent(name);
      setTabs((p) => p.filter((t) => t !== name));
      if (tab === name) setTab("COMONDES");
      return;
    }
    if (!confirm(`مسح الصفحة "${name}"؟`)) return;
    setTabs((p) => p.filter((t) => t !== name));
    setCustom((p) => { const c = { ...p }; delete c[name]; return c; });
    localStorage.removeItem(`sheet_${name}`);
    if (tab === name) setTab("COMONDES");
  };

  const renameTab = (name: string) => {
    const nn = prompt("الاسم الجديد:", name);
    if (!nn || nn === name || tabs.includes(nn)) return;
    if (agentNames.includes(name) && !renameAgent(name, nn)) {
      alert("الاسم موجود أو غير صالح");
      return;
    }
    if (agentNames.includes(name)) {
      users.filter((u) => u.role === "user" && u.agent === name).forEach((u) => updateUser(u.id, { agent: nn.trim() }));
    }
    setTabs((p) => p.map((t) => t === name ? nn : t));
    if (custom[name]) setCustom((p) => { const c = { ...p }; c[nn] = c[name]; delete c[name]; return c; });
    if (tab === name) setTab(nn);
  };

  const sheetData = SHEETS[tab] || custom[tab];

  if (!currentUser) return <Login />;
  if (!isAdmin) {
    return (
      <div className="flex h-screen flex-col bg-white">
        <div dir="rtl" className="flex shrink-0 flex-wrap items-center gap-3 border-b border-slate-300 bg-slate-100 px-3 py-2 text-sm">
          <b>{currentUser.username} · {currentUser.agent}</b>
          <PeriodBar compact />
          <button onClick={logout} className="mr-auto rounded bg-slate-800 px-3 py-1 text-white">خروج</button>
        </div>
        <div className="flex-1 overflow-hidden"><AgentOrders agent={currentUser.agent} /></div>
      </div>
    );
  }

  return (
      <div className="flex h-screen flex-col bg-white">
        {/* ═══ Barre supérieure professionnelle ═══ */}
        <div className="shrink-0 border-b border-slate-200 bg-gradient-to-b from-white to-slate-50 shadow-sm">
          <div className="flex items-center gap-3 px-3 pt-2">
            {/* Logo */}
            <div className="flex shrink-0 items-center gap-2 pe-3">
              <div className="grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-sm text-white shadow-md shadow-indigo-200">📊</div>
              <span className="hidden text-sm font-extrabold tracking-tight text-slate-800 sm:block">RodaMar</span>
            </div>

            {/* Filtre temporel */}
            <div dir="rtl" className="ms-auto flex shrink-0 items-center gap-2">
              <PeriodBar />
            </div>
          </div>

          {/* Onglets */}
          <div dir="ltr" className="flex items-end gap-1 overflow-x-auto px-3 pt-1.5" style={{ scrollbarWidth: "thin" }}>
            {tabs.map((t) => {
              const on = tab === t;
              const locked = LOCKED.includes(t);
              return (
                <div
                  key={t}
                  onClick={() => setTab(t)}
                  onDoubleClick={() => renameTab(t)}
                  title="نقرة مزدوجة لإعادة التسمية"
                  className={`group relative flex shrink-0 cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-t-xl px-4 py-2 text-xs transition-all ${
                    on
                      ? "bg-white font-bold text-indigo-700 shadow-[0_-2px_8px_rgba(0,0,0,0.06)]"
                      : "text-slate-500 hover:bg-white/70 hover:text-slate-800"
                  }`}
                >
                  {on && <span className="absolute inset-x-0 top-0 h-[3px] rounded-t-xl bg-gradient-to-r from-indigo-500 to-violet-500" />}
                  {locked && <span className={on ? "text-amber-500" : "text-slate-400"}>🔒</span>}
                  <span>{t}</span>
                  {!FIXED.includes(t) && (
                    <button
                      onClick={(e) => { e.stopPropagation(); delTab(t); }}
                      className="ml-0.5 hidden h-4 w-4 place-items-center rounded-full text-[10px] text-slate-400 transition hover:bg-red-100 hover:text-red-600 group-hover:grid"
                      title="مسح"
                    >✕</button>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex-1 overflow-hidden">
          {tab === "COMONDES" && <Sheet />}
          {tab === "PRODUITS" && <div className="h-full overflow-auto"><Produits /></div>}
          {tab === "Sheet129" && <div className="h-full overflow-auto"><BlankSheet name="Sheet129" /></div>}
          {tab === "suivi confirmation" && <SuiviConfirmationView />}
          {tab === "إدارة المستخدمين" && <UsersAdmin />}
          {tab === "Historique" && <Historique />}
          {tab === "Work Team" && <WorkTeam onOpen={(name) => setTab(name)} onRanking={() => setTab("Ranking")} onLive={() => setTab("Live Activity")} />}
          {tab === "Ranking" && <Ranking />}
          {tab === "Live Activity" && <LiveActivity />}
          {tab === "Heatmap" && <Heatmap />}
          {agentNames.includes(tab) && (
            <div className="flex h-full flex-col">
              <div dir="ltr" className="flex shrink-0 items-center gap-2 border-b border-indigo-100 bg-indigo-50 px-3 py-1.5">
                <button onClick={() => setTab("Work Team")} className="rounded-lg bg-white px-3 py-1 text-xs font-bold text-indigo-700 shadow-sm hover:bg-indigo-100">
                  ← 👥 Work Team
                </button>
                <span className="text-xs text-indigo-900/70">Page de <b>{tab}</b></span>
              </div>
              <div className="flex-1 overflow-hidden"><AgentOrders agent={tab} /></div>
            </div>
          )}
          {!CUSTOM_VIEWS.includes(tab) && !agentNames.includes(tab) && sheetData && <Grid name={tab} data={sheetData} />}
        </div>

        {/* bottom tabs bar (like Google Sheets) */}
        <div dir="ltr" className="flex shrink-0 items-center overflow-x-auto border-t-2 border-slate-300 bg-[#f5f5f5]" style={{ scrollbarWidth: "thin" }}>
          <button onClick={addTab} title="إضافة صفحة" className="shrink-0 border-r border-slate-300 px-3 py-2 text-base font-bold text-emerald-700 hover:bg-slate-200">＋</button>
          <button onClick={addAgentPage} title="إضافة بنت وصفحتها المربوطة" className="shrink-0 border-r border-slate-300 px-3 py-2 text-xs font-bold text-blue-700 hover:bg-blue-100">👤＋ بنت</button>
          <button onClick={() => setTab("Work Team")} title="Notre équipe" className="shrink-0 border-r border-slate-300 px-3 py-2 text-xs font-bold text-indigo-700 hover:bg-indigo-100">👥 Work Team</button>
          <button onClick={() => setTab("Ranking")} title="Classement des filles (Admin)" className="shrink-0 border-r border-slate-300 px-3 py-2 text-xs font-bold text-amber-700 hover:bg-amber-100">🏆 Ranking</button>
          <button onClick={() => setTab("Live Activity")} title="نشاط الفريق مباشر (Admin)" className="flex shrink-0 items-center gap-1.5 border-r border-slate-300 px-3 py-2 text-xs font-bold text-red-700 hover:bg-red-100">
            <i className="h-2 w-2 animate-pulse rounded-full bg-red-500" /> Live Activity
          </button>
          <button onClick={() => setTab("Heatmap")} title="ساعات العمل والأداء (Admin)" className="shrink-0 border-r border-slate-300 px-3 py-2 text-xs font-bold text-orange-700 hover:bg-orange-100">🔥 Heatmap</button>
          <button onClick={() => setTab("إدارة المستخدمين")} className="shrink-0 border-r border-slate-300 px-3 py-2 text-xs font-bold text-violet-700 hover:bg-violet-100">🔐 Users</button>
          <button onClick={() => setTab("Historique")} className="shrink-0 border-r border-slate-300 px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-200">🕘 Historique</button>
          <button onClick={logout} className="shrink-0 border-r border-slate-300 px-3 py-2 text-xs font-bold text-red-700 hover:bg-red-100">خروج</button>
        </div>
      </div>
  );
}

export default function App() {
  return <AuthProvider><StoreProvider><PeriodProvider><Workspace /></PeriodProvider></StoreProvider></AuthProvider>;
}
