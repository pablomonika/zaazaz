<?php
header('Content-Type: application/json');
echo '{"NEW":true,"time":"' . date('H:i:s') . '"}';
